package com.example.mortgagecalc;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.mortgagecalc.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Declare an alert box to be used in the error handling of null inputs
        AlertDialog.Builder alert = new AlertDialog.Builder(view.getContext());
        //Add backout button onto the alert box that closes the alert box upon "ok" being pressed
        alert.setNegativeButton(
                "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        //add the onClick listener to the calculate button
        binding.calcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //check if the input boxes are empty, by using the Utils library and parsing the numbers to a string
                if(TextUtils.isEmpty(binding.mortgagePrice.getText().toString()))
                {
                    //Tell the user that the mortgage is not set correctly
                    alert.setMessage("Mortgage Price Not Set");
                    alert.setCancelable(true);
                    alert.show();
                }
                else if(TextUtils.isEmpty(binding.interestRate.getText().toString()))
                {
                    //Tell the user that the Interest Rate is not set correctly
                    alert.setMessage("Interest Rate Not Set");
                    alert.setCancelable(true);
                    alert.show();
                }
                else if(TextUtils.isEmpty(binding.paymentPeriod.getText().toString()))
                {
                    //Tell the user that the mortgage Length is not set correctly
                    alert.setMessage("Mortgage Period Not Set");
                    alert.setCancelable(true);
                    alert.show();
                }
                else {
                    //if there are no issues with any of the input boxes
                    //this is done by getting the string value of the input box then parsing to a number int or double
                    int mPrice = Integer.parseInt(binding.mortgagePrice.getText().toString());
                    double mInterest = Float.parseFloat(binding.interestRate.getText().toString());
                    int mLength = Integer.parseInt(binding.paymentPeriod.getText().toString());

                    //pass the price interest and period to the function that calculates the montly payments
                    double monthlyCost = calculatePayments(mPrice, mInterest, mLength);

                    //Create an intent that Calls the Calculate class which is used to display the calculated value
                    Intent i = new Intent(getActivity(), Calculate.class);

                    //create a bundle which is used to pass values to the Calculate class through the intent
                    Bundle b = new Bundle();
                    //add the MonthlyCost, Mortgage Price, Interest Rate and Monthly Term length to the bundle
                    b.putDouble("Cost", monthlyCost);
                    b.putInt("Price", mPrice);
                    b.putDouble("Interest", mInterest);
                    b.putInt("Length", mLength);
                    //add the bundle to the intent
                    i.putExtras(b);
                    //start the intent
                    startActivity(i);
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private double calculatePayments(int mPrice, double mInterest, int mLength){
        double payments;
        double numerator;
        double denominator;

        /**
         * The formula used to calculate the monthly interest rate is as follows
         * M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1] or as written in english below
         * Monthly Payment = Price*(Monthly interest(Monthly interest + 1)^months) / ((1+Monthly interest)^(months)-1)
         * I use this function to perform the above equation in steps
         */

        //convert from decimal value to percentage (2.24% to 0.0224)
        mInterest = mInterest/100;
        //Divide by 12 to get the interest rate per month
        mInterest = mInterest/12;

        //performs the P [ i(1 + i)^n ] part of the equation
        numerator = Math.pow(1+mInterest,mLength);
        numerator = mInterest*numerator;
        numerator = mPrice*numerator;

        //performs the [ (1 + i)^n – 1] part of the equation
        denominator = Math.pow(1+mInterest,mLength);
        denominator-=1;

        //Finally calculate the monthly Payments
        payments = numerator/denominator;

        return payments;
    }

}