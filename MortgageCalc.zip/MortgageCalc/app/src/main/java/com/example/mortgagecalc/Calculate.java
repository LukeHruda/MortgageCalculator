package com.example.mortgagecalc;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.time.temporal.ValueRange;


public class Calculate extends Activity {
    //Create Decimal Format to convert the monthly cost to Dollars and Cents
    private static DecimalFormat df = new DecimalFormat("#.##");
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        //Get the bundle from the intent
        Bundle b = getIntent().getExtras();

        //get the monthly cost, mortgage, interest rate and mortgage period from the bundle
        double monthlyCost = b.getDouble("Cost");
        int price = b.getInt("Price");
        double interest = b.getDouble("Interest");
        int length = b.getInt("Length");

        //Set view to the popup.xml file
        setContentView(R.layout.popup);

        //get the textview from the popup file
        TextView mortgageText = (TextView)findViewById(R.id.monthlyPayment);

        //set that text to the predetermined paragraph
        mortgageText.setText("A $"+String.valueOf(price)+" mortgage at "+
                String.valueOf(interest)+"% over "+
                String.valueOf(length) + " months leads to $" +
                df.format(monthlyCost) + " per month.");

        //get the information on the display size of the current phone
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        //get the width and height of the current phone
        int width = dm.widthPixels;
        int height = dm.heightPixels;

        //set the popup window height to 80% width and 60% height
        getWindow().setLayout((int)(width*0.8),(int)(height*0.6));
    }


}
